package com.skripsi.joes.smartabsensi;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.net.NetworkInterface;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import androidx.appcompat.app.AppCompatActivity;

public class Course extends AppCompatActivity {
    Integer id;
    private Context context;
    private ProgressDialog pDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Toast.makeText(this, "MAC :"+getMacAddr(), Toast.LENGTH_SHORT).show();
        Toast.makeText(this,"user id "+getUserId(), Toast.LENGTH_LONG).show();
        Log.i("", "onCreate: "+getMacAddr());
        absen();
    }

    public static String getMacAddr() {
        try {
            List<NetworkInterface> all = Collections.list(NetworkInterface.getNetworkInterfaces());
            for (NetworkInterface nif : all) {
                if (!nif.getName().equalsIgnoreCase("wlan0")) continue;
                byte[] macBytes = nif.getHardwareAddress();
                if (macBytes == null) {
                    return "";
                }
                StringBuilder res1 = new StringBuilder();
                for (byte b : macBytes) {
                    res1.append(String.format("%02X:",b));
                }
                if (res1.length() > 0) {
                    res1.deleteCharAt(res1.length() - 1);
                }
                return res1.toString();
            }
        } catch (Exception ex) {
        }
        return "";
    }

    private void absen() {
        final String user_id = String.valueOf(getUserId());
        final String mac_addres = getMacAddr();
        final String time = String.valueOf(System.currentTimeMillis());
        StringRequest stringRequest = new StringRequest(Request.Method.POST, AppVar.ABSEN_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.i("", "onResponse: "+response);
                        if (response.contains(AppVar.LOGIN_SUCCESS)) {
                            Toast.makeText(Course.this, "success", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(Course.this,"tidak sesuai", Toast.LENGTH_LONG).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(context, "Server tidak terjangkau", Toast.LENGTH_LONG).show();

                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put(AppVar.USER_ID, user_id);
                params.put(AppVar.MAC_ADDRES, mac_addres);
                params.put(AppVar.TIME, time);
                return params;
            }
        };
        Volley.newRequestQueue(this).add(stringRequest);
    }
    private void showDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }
    private void hideDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }
    private int getUserId(){
        SharedPreferences sharedPreferences =  this.getSharedPreferences("settings", Context.MODE_PRIVATE);
        return sharedPreferences.getInt("id",0);
    }
}
