package com.skripsi.joes.smartabsensi;

import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

public class RunAfterBootService extends Service {

    private static final String TAG_BOOT_EXECUTE_SERVICE = "BOOT_BROADCAST_SERVICE";

    public RunAfterBootService() {
    }


    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG_BOOT_EXECUTE_SERVICE, "RunAfterBootService onCreate() method.");

    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        Log.i("service", "onStartCommand: ");
        createNotification("string","String");
        absen();
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void createNotification(String ssid, String mac) {
        NotificationCompat.Builder mBuilder =
                new NotificationCompat.Builder(RunAfterBootService.this)
                        .setSmallIcon(R.drawable.ftek)
                        .setContentTitle("Absensi Mahasiswa")
                        .setContentText("Silahkan klik untuk absen");
        NotificationManager mNotificationManager = (NotificationManager) getApplicationContext().getSystemService(Context.NOTIFICATION_SERVICE);
        mNotificationManager.notify(1, mBuilder.build());
    }

    private void absen() {
        final String user_id = "1";
        final String mac_addres = "mac_addres";
        final String time = String.valueOf(System.currentTimeMillis());

        StringRequest stringRequest = new StringRequest(Request.Method.POST, AppVar.ABSEN_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.i("", "onResponse: "+response);

                        //If we are getting success from server
                        if (response.contains(AppVar.LOGIN_SUCCESS)) {
                            Log.i("", "onResponse: sukses");

//                            hideDialog();
                        } else {
                            Log.i("", "onResponse: gagal");
//                            hideDialog();
                            //Displaying an error message on toast

                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("onResponse", "onErrorResponse: "+error.getMessage() );

                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                //Adding parameters to request
                params.put(AppVar.USER_ID, user_id);
                params.put(AppVar.MAC_ADDRES, mac_addres);
                params.put(AppVar.TIME, time);
                return params;
            }
        };

        Volley.newRequestQueue(this).add(stringRequest);

    }
}