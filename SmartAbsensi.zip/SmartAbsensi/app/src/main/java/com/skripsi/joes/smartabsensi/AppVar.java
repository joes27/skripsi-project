package com.skripsi.joes.smartabsensi;

/**
 * Created by joe s on 12/03/2018.
 */

public class AppVar {

    //URL to our activity_login.php file, url bisa diganti sesuai dengan alamat server kita
    public static final String LOGIN_URL = "http://192.168.43.63/APIabsensi/login1.php";
    //URL to our absen.php file, url bisa diganti sesuai dengan alamat server kita
    public static final String ABSEN_URL = "http://192.168.43.63/APIabsensi/absen.php";
    //skrip untuk mengambil email dan password login1.php
    public static final String KEY_EMAIL = "nam";
    public static final String KEY_PASSWORD = "ni";
    //response dari server
    public static final String LOGIN_SUCCESS = "success";
    public static final String FAILURE = "failure";

    //skrip untuk mengirim absen in activity_login
    public static final String USER_ID = "user_id";
    public static final String MAC_ADDRES = "mac_addres";
    public static final String TIME = "time";

    public  static final String IP_WIFI = "02:00:00:00:00:00";
}
