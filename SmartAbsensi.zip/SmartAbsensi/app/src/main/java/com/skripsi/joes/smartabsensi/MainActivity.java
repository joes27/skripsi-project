package com.skripsi.joes.smartabsensi;

import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    TextView textEmailAddress,TextPassword;
    String email,password;

    public static final String KEY_PASSWORD = "password";
    public static final String KEY_EMAIL = "email";

    final WifiReceiver wifiReceiver = new WifiReceiver();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final IntentFilter filters = new IntentFilter();
        filters.addAction("android.net.wifi.WIFI_STATE_CHANGED");
        filters.addAction("android.net.wifi.STATE_CHANGE");
        super.registerReceiver(wifiReceiver, filters);

        TextPassword = (TextView) findViewById(R.id.TextPassword);
        textEmailAddress = (TextView) findViewById(R.id.textEmailAddress);

        password = getIntent().getStringExtra(KEY_PASSWORD);
        email = getIntent().getStringExtra(KEY_EMAIL);

        TextPassword.setText("NIM :  + password");
        textEmailAddress.setText("Nama :  + email");

    }

    private void saveIdToPreference (Integer id){
        Log.i("", "saveIdToPreference: id ===> "+id);
        SharedPreferences sharedPreferences = this.getSharedPreferences("settings",MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt("id",id);
        editor.apply();
        editor.commit();
    }

    private int getSharedData(){
        int id = 0;
        SharedPreferences sharedPreferences = this.getSharedPreferences("settings",MODE_PRIVATE);
        id = sharedPreferences.getInt("id",0);
        return id;
    }
}
